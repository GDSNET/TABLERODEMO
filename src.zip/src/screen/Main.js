import React, { Component } from "react";
import {
  Route,
  NavLink,
  HashRouter
} from "react-router-dom";
import Home from "./Home";
import Calidad from "./Calidad";
import Control from "./Control";
//import "../css/index.css";


class Main extends Component {
  render() {
    return (
      <HashRouter>
        <div>
          <h1>Global Dessicion Support</h1>
          <ul className="header">
            
            <li><NavLink to="/homes">Inicio</NavLink></li>
            <li><NavLink to="/control">Control</NavLink></li>
            <li><NavLink to="/calidad">Calidad</NavLink></li>
          </ul>
          <div className="content">
            
            
            <Route path="/homes" component={Home}/>
            <Route path="/control" component={Control}/>
            <Route path="/calidad" component={Calidad}/>
          </div>
        </div>
      </HashRouter>
    );
  }
}

 
export default Main;