import React, { Component } from "react";
import { connect } from "react-redux";
import combinaActions from "../actions/index";
import {bindActionCreators} from 'redux';


 
class Home extends Component {

 


  render() {
    const {controlestado,calidadestado, stopAction, startAction, visible } = this.props;
    return (
      <div>
           
        <p> HOME </p>
        <p> CONTROL:  {controlestado} </p>
        <p> CONTROL:  {calidadestado} </p>


      </div>
    );
  }
}
 

function mapStateToProps(state){
  return{
    
    ...state,
    visible: state.control.visible,
   controlestado: state.control.estado,
  calidadestado: state.calidad.estado

  }
}

function mapDispatchToProps (dispatch) {
 const combiner = Object.assign({},
  combinaActions,
{dispatch}
);
return bindActionCreators(
  combiner,
  dispatch,
);
}



export default connect(mapStateToProps, mapDispatchToProps)(Home);
