import React, { Component } from "react";
import { connect } from "react-redux";
import combinaActions from "../actions/index";
import {bindActionCreators} from 'redux';


 
class Home extends Component {

 
  funExec (){
    const {stopActionCalidad, startActionCalidad, visible } = this.props;
    if (visible){
      
      stopActionCalidad();
    }
    else{
      startActionCalidad()
    }
  }

  funExecVariables( stopActionCalidad, startActionCalidad, visible){
    if (visible){
      stopActionCalidad();
    }
    else{
      startActionCalidad()
    }
  }


  render() {
    const {estado, stopActionCalidad, startActionCalidad, visible } = this.props;
    return (
      <div>
           
        <p> hola:  {estado} </p>
        
        <button style={{width:100 ,height:100}} tittle='Boton' 
        onClick={visible ? stopActionCalidad : startActionCalidad}>
       Funcion On Click
        </button>

        <button style={{width:100 ,height:100}} tittle='Boton' 
        onClick={()=>{this.funExec()}}>
         Funcion Antes Render 
        </button>

        <button style={{width:100 ,height:100}} tittle='Boton' 
        onClick={()=>{this.funExecVariables( stopActionCalidad, startActionCalidad, visible)}}>
         Funcion con Variables
        </button>

      </div>
    );
  }
}
 

function mapStateToProps(state){
  return{
    
    visible: state.calidad.visible,
    estado: state.calidad.estado

  }
}

function mapDispatchToProps (dispatch) {
 const combiner = Object.assign({},
  combinaActions,
{dispatch}
);
return bindActionCreators(
  combiner,
  dispatch,
);
}



export default connect(mapStateToProps, mapDispatchToProps)(Home);
