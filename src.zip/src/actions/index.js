import * as controlActions from './controlActions'
import * as calidadActions from './calidadActions'

const combinaActions = Object.assign({}, controlActions, calidadActions);

export default combinaActions;