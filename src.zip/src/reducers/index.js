


import { combineReducers } from 'redux';
import controlReducers from './controlReducers'
import calidadReducers from './calidadReducers'

const rootReducer = combineReducers({
    control: controlReducers,
    calidad: calidadReducers
})
export default rootReducer