export const START_ACTION = 'START_ACTION';
export const STOP_ACTION = 'STOP_ACTION';

export const AGREGAR_NUMERO = 'AGREGAR_NUMERO';